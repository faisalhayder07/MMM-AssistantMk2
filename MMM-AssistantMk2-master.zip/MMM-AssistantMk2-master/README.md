# MMM-AssistantMk2

## AssistantMk2 v3.6 (Final)
This module is a pure version of GoogleAssistant without any plugins.<br>
There is no visual response: ONLY audio response.<br>
No MMM-Hotword needed (a detector is embed)<br>
If you don't need plugins or assistant for launching program<br>
This module is yours !

## Installation, update & Guides
Read the docs in [wiki](https://github.com/bugsounet/MMM-AssistantMk2/wiki)<br>

## Notes:
I consider this module like OUTDATED and deprecied.

If you want an modern Assistant use:
[MMM-GoogleAssistant](https://github.com/bugsounet/MMM-GoogleAssistant)
and [MMM-Assistant2Display](https://github.com/bugsounet/MMM-Assistant2Display) extension
